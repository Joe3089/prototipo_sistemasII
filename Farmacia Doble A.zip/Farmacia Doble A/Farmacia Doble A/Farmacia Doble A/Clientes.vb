﻿Public Class Clientes
    Private Sub btnBorrar_Click(sender As Object, e As EventArgs) Handles btnBorrar.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub BtnBUscar_Click(sender As Object, e As EventArgs) Handles BtnBUscar.Click
        MessageBox.Show("No encuentra el Cliente", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        MessageBox.Show("Cliente registrado con Exito!!", "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information)
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub
End Class