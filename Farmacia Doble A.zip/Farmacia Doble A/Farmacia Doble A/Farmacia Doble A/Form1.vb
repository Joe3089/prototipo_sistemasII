﻿Public Class Login
    Private Sub BtnIniciarSesion_Click(sender As Object, e As EventArgs) Handles BtnIniciarSesion.Click
        If TxtUser.Text = "admin" And TxtPass.Text = "admin" Then
            Login.ActiveForm.Hide()
            Dim form As New FormPrincipal
            form.Show()
        Else
            MessageBox.Show("Usuario o Contraseña Incorrectos", "Login Farmacia Doble A", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub
End Class
