﻿Public Class Medicamentos
    Private Sub Medicamentos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnBuscarMedicamento_Click(sender As Object, e As EventArgs) Handles btnBuscarMedicamento.Click
        txtMedicamento.Text = ""
        MessageBox.Show("No encuentra el medicamento", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub
End Class