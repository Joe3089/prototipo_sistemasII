﻿Public Class Pascientes
    Private Sub BtnBorrar_Click(sender As Object, e As EventArgs) Handles BtnBorrar.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        MessageBox.Show("Pasciente Guardado con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information)
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        MessageBox.Show("No se encontro el Pasciente!!", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub
End Class