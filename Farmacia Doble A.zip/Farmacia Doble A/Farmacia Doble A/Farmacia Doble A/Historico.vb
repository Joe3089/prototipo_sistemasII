﻿Public Class Historico
    Private Sub BtnBorrar_Click(sender As Object, e As EventArgs) Handles BtnBorrar.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        MessageBox.Show("Historico Guardado con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information)
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        TextBox3.Text = ""
        MessageBox.Show("No encuentra el Historial", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub
End Class